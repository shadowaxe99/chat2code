# DashDashStash

DashDashStash is an amorphic AI agent that can interact with users through various communication channels like voice, chat, email, and text. It leverages advanced AI algorithms to provide intelligent responses and perform tasks based on user inputs.

## Installation

To install DashDashStash, follow these steps:

1. Clone the repository: `git clone https://github.com/shadowaxe99/dashdashstash.git`
2. Navigate to the project directory: `cd dashdashstash`
3. Install the required dependencies: `pip install -r requirements.txt`

## Usage

To use DashDashStash, run the following command:

```python
python src/ai_agent/main.py
```

## Contributing

Contributions are welcome! If you have any ideas, suggestions, or bug reports, please open an issue or submit a pull request.

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for more details.