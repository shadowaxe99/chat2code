class BlockchainManager:
    def __init__(self):
        pass

    def connect_to_blockchain(self):
        pass

    def send_transaction(self, transaction):
        pass

    def read_data(self, data_key):
        pass