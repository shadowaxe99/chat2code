class UserAgentNFTs:
    def __init__(self):
        pass

    def create_nft(self, user_id):
        pass

    def transfer_nft(self, user_id, recipient):
        pass

    def update_nft(self, user_id, data):
        pass