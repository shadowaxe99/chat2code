class ChatProcessor:
    def __init__(self):
        pass

    def process_chat(self, chat_data):
        pass

    def extract_entities(self, chat_data):
        pass

    def analyze_sentiment(self, chat_data):
        pass