class UserInterface:
    def __init__(self):
        pass

    def display_message(self, message):
        pass

    def get_user_input(self):
        pass

    def show_loading_indicator(self):
        pass

    def hide_loading_indicator(self):
        pass