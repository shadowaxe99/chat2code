class GroupTextConversations:
    def __init__(self):
        pass

    def create_conversation(self):
        pass

    def join_conversation(self, conversation_id):
        pass

    def send_message(self, conversation_id, message):
        pass

    def receive_message(self, conversation_id, message):
        pass