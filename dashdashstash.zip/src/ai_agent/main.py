from ai_agent.amorphic_ai_agent import AmorphicAIAgent

if __name__ == '__main__':
    agent = AmorphicAIAgent()
    agent.interact_with_user()