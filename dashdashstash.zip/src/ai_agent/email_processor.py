class EmailProcessor:
    def __init__(self):
        pass

    def fetch_emails(self):
        pass

    def process_emails(self, emails):
        pass

    def extract_content(self, email):
        pass

    def analyze_sentiment(self, content):
        pass