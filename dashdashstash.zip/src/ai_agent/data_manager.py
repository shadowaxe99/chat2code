class DataManager:
    def __init__(self):
        pass

    def load_data(self, data_path):
        pass

    def preprocess_data(self, data):
        pass

    def save_data(self, data, save_path):
        pass