class PrivacySettings:
    def __init__(self):
        pass

    def set_privacy(self, privacy_level):
        pass

    def get_privacy(self):
        pass