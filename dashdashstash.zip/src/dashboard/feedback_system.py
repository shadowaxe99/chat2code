class FeedbackSystem:
    def __init__(self):
        pass

    def submit_feedback(self, feedback):
        pass

    def view_feedback(self):
        pass