class HelpSupport:
    def __init__(self):
        pass

    def get_help(self):
        pass

    def submit_support_request(self, request):
        pass